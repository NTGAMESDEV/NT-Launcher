
package com.ntlauncher.mobile;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
 @Override
 protected void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  Button b = new Button(this);
  b.setText("NT Launcher READY");
  setContentView(b);
 }
}
